# ThreadPool
Learning new fetures of C++11, and using them to implement a simple thread pool.

lambda expressions, std::thread, std::future, std::packaged_task, std::move, std::unique_lock, std::condition_variable, std::mutex, std::shared_ptr, varidic templates... Lot to learn in C++11 !

Reference project: [progschj](https://github.com/progschj/ThreadPool)
